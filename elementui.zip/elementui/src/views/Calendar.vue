<template>
  <el-row>
    <el-col :span="18" :offset="3">
      <el-calendar :range="['2019-03-04', '2020-03-24']" />
    </el-col>
  </el-row>
</template>
