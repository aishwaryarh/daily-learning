<template>
  <div class="home-page">
    <el-header>
      <h1>Home Page</h1>
    </el-header>
  </div>
</template>

<script>
export default {
  name: 'home',
  components: {
  }
}
</script>

<style scoped>
h1 {
  text-align: center;
  font-weight: 400;
}
</style>
